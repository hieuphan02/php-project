<!DOCTYPE html>
<html lang="en">

<head>
    <title>My Friend System | About</title>
    <meta charset="utf-8">
    <meta name="description" content="A simplified social network application.">
    <meta name="keywords" content="social, network">
    <link rel="stylesheet" href="css/style.css">
</head>
<?php include_once "functions.php"; ?>

<body>
    <div>
        <div class="topheading">
            <a href="index.php">
                <span class="logo">
                    <img src="img/myfriend.jpg" alt="MFS" />
                    <p><b>My Friend System</b></p>
                </span>
            </a>
        </div>
        <?php $navItem = "about";
        include "navbar.php"; ?>
        <div>
            <div class="main-page">
                <h1>About</h1>
            </div>
            <div class="side-bar">
                <p>
                    <?php echo "PHP version: " . phpversion(); ?>
                </p>
            </div>
        </div>
        <div>
            <p><b>"What tasks you have not attempted or not completed?"</b></p>
            <p>
            <ul>
                <li>All tasks.</li>
            </ul>
            </p>
            <p><b>"What special features have you done, or attempted, in creating the site that we should know about?"</b></p>
            <ul>

                <li>Addfriend button and the new friend will be indicated in the friend list.</li>
            </ul>
            <p><b>"Which parts did you have trouble with?"</b></p>
            <ul>
                <li>Hanldle query and db.</li>
                <li>After pressing the addfriend and remove friend buttons, it does not go back to the friendlist page however the data has validated in the friendlist
                    <br>
                    Links could not work using relative addressing <br>Update: Already fixed
                </li>
            </ul>
            <p><b>"What would you like to do better next time?"</b></p>
            <ul>
                <li>Css framework and database stuff.</li>
            </ul>
            <p><b>"What additional features did you add to the assignment?"</b></p>
            <p>None</p>
            <p>
                <b>Links</b>
            <ul>
                <li><a href="friendlist.php">friendlist.php</a></li>
                <li><a href="friendadd.php">friendadd.php </a></li>
                <li><a href="index.php">index.php</a></li>
            </ul>
            </p>
            <p><b>"A screen shot of a discussion response that answered someone’s thread in the unit’s discussion board for Assignment 2?"</b></p>
            <p>Did not attempted because our unit does not have a discussion board.</p>
        </div>
    </div>
</body>

</html>