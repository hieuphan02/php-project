<?php
// this php function file hanldle account
class Account
{
    private $db;
    private $id;
    private $email;
    private $profileName;
    private $startDate;
    private $numberOfFriends;

  // constructor

    public function __construct($db, $userId)
    {
        $this->db = $db;
        $this->id = $userId;
        $this->email = null;
        $this->profileName = null;
        $this->startDate = null;
        $this->numberOfFriends = null;
    }

   //  get the account's email

    public function getUserEmail()
    {
        $dbConn = $this->db->getNewConnection();
        $_id = $this->id;
        $query = "SELECT `friend_email` FROM friends WHERE `friend_id` = '$_id'";
        $result = mysqli_query($dbConn, $query);
        if ($result) {
            while ($row = mysqli_fetch_assoc($result)) {
                $this->email = $row["friend_email"];
            }
        }
        $this->db->closeConnection();
        return $this->email;
    }

    // get the account's id

    public function getUserId()
    {
        $dbConn = $this->db->getNewConnection();
        $_id = $this->id;
        $query = "SELECT `friend_id` FROM friends WHERE `friend_id` = '$_id'";
        $result = mysqli_query($dbConn, $query);
        if ($result) {
            while ($row = mysqli_fetch_assoc($result)) {
                $this->id = (int)$row["friend_id"];
            }
        }
        $this->db->closeConnection();
        return $this->id;
    }

      // get the account's profile name

    public function getProName()
    {
        $dbConn = $this->db->getNewConnection();
        $_id = $this->id;
        $query = "SELECT `profile_name` FROM friends WHERE `friend_id` = '$_id'";
        $result = mysqli_query($dbConn, $query);
        if ($result) {
            while ($row = mysqli_fetch_assoc($result)) {
                $this->profileName = $row["profile_name"];
            }
        }
        $this->db->closeConnection();
        return $this->profileName;
    }
      // get the account's started date
    public function getStartDate()
    {
        $dbConn = $this->db->getNewConnection();
        $_id = $this->id;
        $query = "SELECT `date_started` FROM friends WHERE `friend_id` = '$_id'";
        $result = mysqli_query($dbConn, $query);
        if ($result) {
            while ($row = mysqli_fetch_assoc($result)) {
                $this->startDate = $row["date_started"];
            }
        }
        $this->db->closeConnection();
        return $this->startDate;
    }

       // get the account's number of friends

    public function getNumberOfFriends()
    {
        $dbConn = $this->db->getNewConnection();
        $_id = $this->id;
        $query = "SELECT `num_of_friends` FROM friends WHERE `friend_id` = '$_id'";
        $result = mysqli_query($dbConn, $query);
        if ($result) {
            while ($row = mysqli_fetch_assoc($result)) {
                $this->numberOfFriends = (int)$row["num_of_friends"];
            }
        }
        $this->db->closeConnection();
        return $this->numberOfFriends;
    }

    // get the account's number of friends

    public function setNumberOfFriends($number)
    {
        $dbConn = $this->db->getNewConnection();
        $_id = $this->id;
        $query = "UPDATE friends SET `num_of_friends` = '$number' WHERE `friend_id` = '$_id'";
        if ($this->getNumberOfFriends() >= 0) {
            $result = mysqli_query($dbConn, $query);
            if ($result) {
                return TRUE;
                $this->db->closeConnection();
            }
        }
        $this->db->closeConnection();
        return FALSE;
    }
}
?>