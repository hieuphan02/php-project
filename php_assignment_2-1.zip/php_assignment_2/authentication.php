<?php
// this php function file hanldle authentication
class Auth
{
    private $db;
    private $userId;
    private $key;

// constructor
    public function __construct($db)
    {
        $this->db = $db;
    }

    // Update the session
    private function updateSession($userId, $key)
    {
        $authenticationSession = array();
        $authenticationSession["USER_ID"] = $userId;
        $authenticationSession["KEY"] = $key;
        $_SESSION["AUTHENTICATION_SESSION"] = $authenticationSession;
    }

// check if email is registered or not
    public function checkEmail($email)
    {
        $dbConn = $this->db->getNewConnection();
        $isUnique = true;
        $query = "SELECT `friend_email` FROM friends WHERE `friend_email` = '$email'";
        $result = mysqli_query($dbConn, $query);
        if (mysqli_num_rows($result) > 0) {
            $isUnique = false;
        }
        $this->db->closeConnection();
        return $isUnique;
    }

    // register an account
    public function accountRegister($email, $profileName, $password)
    {
        $dbConn = $this->db->getNewConnection();
        $isUnique = $this->checkEmail($email);
        $result = null;
        if ($isUnique) {
            $currentDate = date("Y/m/d");
            $query = "INSERT INTO `friends` (`friend_email`, `password`, `profile_name`, `date_started`, `num_of_friends`)
                        VALUES ('$email', '$password', '$profileName', '$currentDate', 0);
            ";
            $result = mysqli_query($dbConn, $query);
        }
        if ($result) {
            return true;
            $this->db->closeConnection();
        }
        $this->db->closeConnection();
        return false;
    }

    // login and update the session 
    public function accountLogin($email, $password)
    {
        $dbConn = $this->db->getNewConnection();
        $query = "SELECT `friend_id` FROM friends WHERE `friend_email` = '$email' AND `password` = '$password'";
        $result = mysqli_query($dbConn, $query);
        if ($result) {
            while ($row = mysqli_fetch_assoc($result)) {
                $this->userId = $row["friend_id"];
                $this->key = md5(uniqid($this->userId, true));
                $this->updateSession($this->userId, $this->key);
            }
        }
        $this->db->closeConnection();
    }

    // logout and update the session
    public function accountLogout()
    {
        $this->userId = null;
        $this->key = null;
        $this->updateSession($this->userId, $this->key);
    }

    // check if user is authenticated
    public function checkAuthentication()
    {
        if (isset($_SESSION["AUTHENTICATION_SESSION"])) {
            if ($_SESSION["AUTHENTICATION_SESSION"]["USER_ID"]) {
                return true;
            }
        }
        return false;
    }

    // get the session
    public function getAuthSession()
    {
        return $_SESSION["AUTHENTICATION_SESSION"];
    }
}
?>