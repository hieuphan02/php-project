<?php
// this php function file hanldle database
class DB
{
    private $host;
    private $user;
    private $pswd;
    private $dbnm;

    private $dbConnection;

 // constructor
    public function __construct()
    {
        include "settings.php";
        $this->host = $host;
        $this->user = $user;
        $this->pswd = $pswd;
        $this->dbnm = $dbnm;
    }

// close current connection
    public function closeConnection()
    {
        if ($this->dbConnection) {
            if (mysqli_ping($this->dbConnection)) {
                mysqli_close($this->dbConnection);
            }
        }
    }

// set new connection
    public function setNewConnection()
    {
        $this->dbConnection = mysqli_connect($this->host, $this->user, $this->pswd, $this->dbnm);
    }

// get new database connection
    public function getNewConnection()
    {
        $this->setNewConnection();
        return $this->dbConnection;
    }
// get current database connection
    public function getCurrentConnection()
    {
        return $this->dbConnection;
    }

// set up the database
    public function setUpDb()
    {
        $this->setNewConnection();
        $query = "CREATE TABLE IF NOT EXISTS friends (
                `friend_id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
                `friend_email` VARCHAR(50) NOT NULL,
                `password` VARCHAR(20) NOT NULL,
                `profile_name` VARCHAR(30) NOT NULL,
                `date_started` DATE NOT NULL,
                `num_of_friends` INT UNSIGNED,
                UNIQUE (friend_email)
            );
            CREATE TABLE IF NOT EXISTS myfriends (
                `friend_id1` INT NOT NULL,
                `friend_id2` INT NOT NULL,
                CHECK (friend_id1 != friend_id2)
            );
            ALTER TABLE `myfriends`
                    ADD CONSTRAINT `FK_friend_id1`
                    FOREIGN KEY (`friend_id1`)
                    REFERENCES `friends` (`friend_id`)
                    ON DELETE CASCADE
                    ON UPDATE CASCADE,
                    ADD CONSTRAINT `FK_friend_id2`
                    FOREIGN KEY (`friend_id2`)
                    REFERENCES `friends` (`friend_id`)
                    ON DELETE CASCADE
                    ON UPDATE CASCADE;
            INSERT INTO `friends` (`friend_id`,`friend_email`, `password`, `profile_name`, `date_started`, `num_of_friends`) VALUES
                (1, 'hp190702@gmail.com', '123456', 'Hiếu Phan', '2002/07/19', 2),
                (2, 'hienham5@gmail.com', '654321', 'Gia Hiển', '2005/04/17', 2),
                (3, 'huyenngu02@gmail.com', '135790', 'Khánh Huyền', '2002/07/07', 2),
                (4, 'quyenbim@gmail.com', '141002', 'Phương Quyên', '2002/10/14', 2),
                (5, 'tramanh@gmail.com', '987443', 'Trâm Anh', '2002/02/15', 2),
                (6, 'thongu22@gmail.com', '180202', 'Hữu Thọ', '2002/02/18', 2),
                (7, 'vha@gmail.com', '081002', 'Vân Hà', '2002/10/08', 2),
                (8, 'bongu@gmail.com', '290702', 'Tấn Minh', '2002/10/10', 2),
                (9, 'viettuan@gmail.com', '324233', 'Việt Tuấn', '2002/08/08', 2),
                (10,'chaubu@gmail.com', '180402', 'Minh Châu', '2002/04/18', 2);
            INSERT INTO `myfriends` (`friend_id1`, `friend_id2`) VALUES
                (1, 2),
                (2, 3),
                (3, 4),
                (4, 5),
                (5, 6),
                (6, 7),
                (7, 8),
                (8, 9),
                (9, 10),
                (10, 1),
                (1, 3),
                (2, 4),
                (3, 5),
                (4, 6),
                (5, 7),
                (6, 8),
                (9, 2),
                (9, 1),
                (10, 3),
                (10, 2);
        ";
        $result = mysqli_multi_query($this->dbConnection, $query);
        if ($result) {
            return true;
        }
        return false;
    }
}
