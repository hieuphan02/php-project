<?php
include_once "functions.php";
$db = new DB();
$auth = new Auth($db);
if (!$auth->checkAuthentication()) {
    header("Location: index.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>My Friend System | Friend Add</title>
    <meta charset="utf-8">
    <meta name="description" content="A simplified social network application.">
    <meta name="keywords" content="social, network">
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <div >
        <div class="topheading">
            <a href="index.php">
                <span class="logo">
                    <img src="img/myfriend.jpg" alt="MFS" />
                                        <p><b>My Friend System</b></p>

                </span>
            </a>
        </div>
        <?php $navItem = "friendadd";
        include "navbar.php"; ?>
        <?php
        $session = $auth->getAuthSession();
        $friends = new Friends($db);
        $userAccount = new Account($db, $session["USER_ID"]);
        $pageNum = 0;
        if (isset($_GET["page"])) {
            $pageNum = $_GET["page"];
        }
        if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST)) {
            if (isset($_POST["addFriend"]) && $_POST["addFriend"] != NULL) {
                $friendId = $_POST["addFriend"];
                $friendAccount = new Account($db, $friendId);
                if ($friends->addFriend($userAccount, $friendAccount)) {
                    header("Location: friendadd.php?page=$pageNum"); 
                }
            }
        }
        $friendList = $friends->getFriendList($userAccount->getUserId());
        $allAccList = $friends->getAccList($userAccount->getUserId());
        $accList = array_diff($allAccList, $friendList);
        $pageArr = array_chunk($accList, 5, TRUE);
        $pageList = array();
        if (array_key_exists(($pageNum), $pageArr)) {
            $pageList = $pageArr[$pageNum];
        }

        ?>
        <div >
            <div class="main-page">
                <?php echo "<h1>Welcome {$userAccount->getProName()}!</h1>" ?>
                <?php echo "<p>Friend list. (You have {$userAccount->getNumberOfFriends()} friends)</p>" ?>
            </div>
            <div class="side-bar">
            </div>
        </div>
        <div >
            <?php
            $accCount = count($accList);
            if ($accCount > 1) {
                if ($accCount == 1) {
                    echo "<p>$accCount account found</p>";
                } else {
                    echo "<p>$accCount accounts found</p>";
                }
            }
            if (!empty($pageList)) {
                echo "<div id=\"account-table\" class=\"table\">";
                foreach ($pageList as $a) {
                    $account = new Account($db, $a);
                    $mutualFriendCount = $friends->getMutualFriendCount($userAccount->getUserId(), $account->getUserId());
                    $mutualFriendCountStr = $mutualFriendCount == 1 ? "$mutualFriendCount mutual friend" : "$mutualFriendCount mutual friends";
                    echo "<div class=\"table-row\">";
                    echo "<div class=\"table-item\">{$account->getProName()}</div>";
                    echo "<div class=\"table-item\">$mutualFriendCountStr</div>";
                    echo "
                    <div class=\"table-item\">
                    <form action=\"\" method=\"POST\">
                    <input type=\"hidden\" name=\"addFriend\" value=\"{$account->getUserId()}\" />
                    <button class=\"outline small\" type=\"submit\">Add friend</button>
                    </form>
                    </div>
                ";
                    echo "</div>";
                }
                echo "</div>";
            } else {
                echo "<p>No account found!</p>";
            }

            ?>
            <?php
            $pageArr;
            $pageNum;
            include "pagination.php"; ?>
        </div>
    </div>
</body>

</html>