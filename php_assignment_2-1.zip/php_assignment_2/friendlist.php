<?php
include_once "functions.php";
$db = new DB();
$auth = new Auth($db);

if (!$auth->checkAuthentication()) {
    header("Location: index.php");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>My Friend System | Friend List</title>
    <meta charset="utf-8">
    <meta name="description" content="A simplified social network application.">
    <meta name="keywords" content="social, network">
    <link rel="stylesheet" href="css/style.css">
</head>


<body>
    <div >
        <div class="topheading">
            <a href="index.php">
                <span class="logo">
                    <img src="img/myfriend.jpg" alt="MFS" />
                                        <p><b>My Friend System</b></p>

                </span>
            </a>
        </div>
        <?php $navItem = "friendlist";
        include "navbar.php"; ?>
        <?php
        $session = $auth->getAuthSession();
        $userAccount = new Account($db, $session["USER_ID"]);
        $friends = new Friends($db);
        if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST)) {
            if (isset($_POST["unfriend"]) && $_POST["unfriend"] != NULL) {
                $friendId = filter_var($_POST["unfriend"], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
                $friendAccount = new Account($db, $friendId);
                $friends->removeFriend($userAccount, $friendAccount);
                header("Location: friendlist.php");
            }
        }
        $friendList = $friends->getFriendList($userAccount->getUserId());
        $friendList = sortIDsByProName($db, $friendList);
        ?>
        <div >
            <div class="main-page">
                <?php echo "<h1>Welcome {$userAccount->getProName()}!</h1>" ?>
                <?php echo "<p>Friend list. (You have {$userAccount->getNumberOfFriends()} friends)</p>" ?>
            </div>
            <div class="side-bar">
            </div>
        </div>
        <div >
            <?php
            if (!empty($friendList)) {
                echo "<div id=\"friend-table\" class=\"table\">";
                foreach ($friendList as $f) {
                    $friendAccount = new Account($db, $f);

                    echo "<div class=\"table-row\">";
                    echo "<div class=\"table-item\">{$friendAccount->getProName()}</div>";
                    echo "
                    <div class=\"table-item\">
                    <form action=\"\" method=\"POST\">
                    <input type=\"hidden\" name=\"unfriend\" value=\"{$friendAccount->getUserId()}\" />
                    <button class=\"outline small danger\" type=\"submit\">Remove friend</button>
                    </form>
                    </div>
                ";
                    echo "</div>";
                }
                echo "</div>";
            } else {
                echo "<p>You have no friends, such a shame</p>";
            }
            ?>
        </div>
    </div>
</body>

</html>