<?php
if (!isset($_SESSION)) {
    session_start();
}
include_once "acc.php";
include_once "authentication.php";
include_once "db.php";
include_once "friends.php";
include_once "manage.php";

function destroySession(){
    if (!isset($_SESSION)) {
        session_destroy();
    }
}
?>
