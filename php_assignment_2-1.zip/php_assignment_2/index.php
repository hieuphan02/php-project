<!DOCTYPE html>
<html lang="en">

<head>
    <title>My Friend System | Assignment Home Page</title>
    <meta charset="utf-8">
    <meta name="description" content="A simplified social network application.">
    <meta name="keywords" content="social, network">
    <link rel="stylesheet" href="css/style.css">
</head>
<?php include_once "functions.php"; ?>

<body>
    <div >
        <div class="topheading">
            <a href="index.php">
                <span class="logo">
                    <img src="img/myfriend.jpg" alt="MFS" />
                                        <p><b>My Friend System</b></p>

                </span>
            </a>
        </div>
        <?php $navItem = NULL;
        include "navbar.php"; ?>
        <div >
            <div class="main-page">
                <h1>My Friend System</h1>
                <p>Assignment Home Page</p>
            </div>
            <div class="side-bar">
                <p>
                    Name: Phan Trọng Hiếu</br>
                    Id : 103426489
                    </br>

                    I declare that this assignment is my individual work. I have not worked collaboratively nor have I
                    copied from any other student’s work or from any other source.
                </p>
            </div>
        </div>
        <div >
            <?php
            $db = new DB();

            if ($db->setUpDb()) {
                echo "<p class=\"success-text\">Tables successfully created and populated!</p>";
            } else {
                echo "<p class=\"error-text\">Unable to setup tables.</p>";
            }
            ?>
        </div>
    </div>
</body>

</html>