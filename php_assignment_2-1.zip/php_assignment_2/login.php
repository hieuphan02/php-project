<?php
include_once "functions.php";
$db = new DB();
$auth = new Auth($db);
if ($auth->checkAuthentication()) {
    header("Location: index.php");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>My Friend System | Login</title>
    <meta charset="utf-8">
    <meta name="description" content="A simplified social network application.">
    <meta name="keywords" content="social, network">
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <div >
        <div class="topheading">
            <a href="index.php">
                <span class="logo">
                    <img src="img/myfriend.jpg" alt="MFS" />
                                        <p><b>My Friend System</b></p>

                </span>
            </a>
        </div>
        <?php $navItem = "accountLogin";
        include "navbar.php"; ?>
        <div >
            <div class="main-page">
                <h1>Login</h1>
                <p>Login to your My Friend System account.</p>
            </div>
            <div class="side-bar">
                <form method="POST" action="" novalidate="novalidate">
                    <?php
                    $fEmail = NULL;
                    $fPassword = NULL;
                    $fErrors = array();
                    $processErrors = array();
                    if (isset($_SESSION["fEmail"])) {
                        $fEmail = $_SESSION["fEmail"];
                    }
                    if (isset($_SESSION["fErrors"])) {
                        $fErrors = $_SESSION["fErrors"];
                    }
                    if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST)) {
                        if (isset($_POST["email"]) && $_POST["email"] != NULL) {
                            $fEmail = filter_var($_POST["email"], FILTER_SANITIZE_EMAIL);
                            if (!filter_var($fEmail, FILTER_VALIDATE_EMAIL)) {
                                $fErrors["email"] = "Please enter a valid email";
                            }
                        } else {
                            $fErrors["email"] = "Enter your email";
                        }
                        if (isset($_POST["password"]) && $_POST["password"] != NULL) {
                            $fPassword = filter_var($_POST["password"], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
                            if (!preg_match("/[\w\d]{0,20}/", $fPassword)) {
                                $fErrors["password"] = "Please a valid password";
                            }
                        } else {
                            $fErrors["password"] = "Enter your password";
                        }
                        if (empty($fErrors)) {
                            if (!$auth->checkEmail($fEmail)) {
                                $auth->accountLogin($fEmail, $fPassword);
                                if ($auth->checkAuthentication()) {
                                    header("Location: friendlist.php");
                                } else {
                                    $processErrors["Cannot login"] = "Your email and password are incorrect.";
                                }
                            } else {
                                $processErrors["Login error"] = "Account does not exist";
                            }
                        }
                        $_SESSION["fEmail"] = $fEmail;
                        $_SESSION["errors"]["fErrors"] = $fErrors;
                        $_SESSION["errors"]["processErrors"] = $processErrors;
                    }
                    unset($_SESSION["fEmail"]);
                    unset($_SESSION["errors"]);
                    ?>
                    <div class="form-attribute">
                        <label for="email">Email</label>
                        <input id="email"  type="text" name="email" placeholder="Enter your email" required="required" value="<?php echo $fEmail; ?>" />
                        <?php if (array_key_exists("email", $fErrors)) echo "<div class=\"form-error-feedback\">" . $fErrors["email"] . "</div>"; ?>
                    </div>
                    <div class="form-attribute">
                        <label for="password">Password</label>
                        <input id="password"  type="password" name="password" placeholder="Enter your password" required="required" />
                        <?php if (array_key_exists("password", $fErrors)) echo "<div class=\"form-error-feedback\">" . $fErrors["password"] . "</div>"; ?>
                    </div>
                    <button type="submit" class="outline">Login</button>
                </form>
            </div>
        </div>
        <div >
            <?php
            if ($processErrors) {
                foreach ($processErrors as $key => $value) {
                    echo "<h1>$key</h1>";
                    echo "<p>$value</p>";
                }
            }
            ?>
        </div>
    </div>
</body>

</html>