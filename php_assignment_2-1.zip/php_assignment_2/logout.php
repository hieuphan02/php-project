<?php
include_once "functions.php";

$db = new DB();
$auth = new Auth($db);
$auth->accountLogout();

if (!$auth->checkAuthentication()) {
    destroySession();
    header('Location: index.php');
} else {
    echo "Error logging out!";
}
?>