<nav class="navigation">
    <?php
    $db = new DB();
    $auth = new Auth($db);
    $isAuth = $auth->checkAuthentication();
    if($isAuth){
        $session = $auth->getAuthSession();
        $userAccount = new Account($db, $session["USER_ID"]);
    }

    ?>
    <ul>
        <?php 
        if ($isAuth){ 
            if ($navItem == "friendlist") {
                echo "<li class=\"active-hover\">";
            } else {
                echo "<li class=\"\">";
            }
            echo "<a href=\"friendlist.php\" >Friend List</a>";
            echo "</li>";
            if ($navItem == "friendadd") {
                echo "<li class=\"active-hover\">";
            } else {
                echo "<li class=\"\">";
            }
            echo "<a href=\"friendadd.php\" >Add Friends</a>";
            echo "</li>";
        } else {
            if ($navItem == "signup") {
                echo "<li class=\"active-hover\">";
            } else {
                echo "<li class=\"\">";
            }
            echo "<a href=\"signup.php\" >Signup</a>";
            echo "</li>";
        }
        ?>
        <li class="<?php if($navItem == "accountLogin") echo "active-hover"; ?>">
            <?php 
            if ($isAuth){ 
                echo "<a href=\"logout.php\" >Logout ({$userAccount->getProName()})</a>";
            } else {
                echo "<a href=\"login.php\" >Login</a>";
            }
            ?>
        </li>
        <li class="<?php if($navItem == "about") echo "active-hover"; ?>">
            <a href="about.php" >About</a>
        </li>
    </ul>
</nav>