<nav class="pagination">
    <ul>
        <?php
            if(array_key_exists(($pageNum - 1), $pageArr)){
                $previousPage = $pageNum - 1;
                echo "
                    <li class=\"page-item\">
                        <a class=\"page-link\" href=\"?page={$previousPage}\" tabindex=\"-1\">Previous</a>
                    </li>
                ";
            }
        ?>
        <?php
            if(array_key_exists(($pageNum + 1), $pageArr)){
                $nextPage = $pageNum + 1;
                echo "
                    <li class=\"page-item\">
                        <a class=\"page-link\" href=\"?page={$nextPage}\">Next</a>
                    </li>
                ";
            }
        ?>
    </ul>
</nav>