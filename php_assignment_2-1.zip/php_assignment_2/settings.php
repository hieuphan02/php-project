<?php 
$host = "feenix-mariadb.swin.edu.au"; 
$user = "s103426489"; // your user name 
$pswd = "190702"; // your password d(date of birth – ddmmyy) 
$dbnm = "s103426489_db"; // your database 
?> 