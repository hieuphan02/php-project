<?php 
include_once "functions.php";
$db = new DB();
$auth = new Auth($db);

if ($auth->checkAuthentication()){
    header("Location: index.php"); 
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>My Friend System | Signup</title>
    <meta charset="utf-8">
    <meta name="description" content="A simplified social network application.">
    <meta name="keywords" content="social, network">
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <div >
    <div class="masthead">
    <a href="index.php" >
        <span class="logo">
            <img src="img/myfriend.jpg" alt="MFS" />
                                <p><b>My Friend System</b></p>

        </span>
    </a>
</div>
        <?php $navItem = "signup"; include "navbar.php";?>
        <div >
            <div class="page-header">
                <h1>Signup</h1>
                <p>Register for My Friends System.</p>
            </div>
            <div class="side-bar">
            </div>
        </div>
        <div >
            <form method="POST" action="" novalidate="novalidate">
                <?php
                    $fEmail = NULL;
                    $fName = NULL;
                    $fPassword = NULL;
                    $fCfPassword = NULL;
                    $fErrors = array();
                    $processErrors = array();
                    if (isset($_SESSION["fEmail"])){
                        $fEmail = $_SESSION["fEmail"];
                    }
                    if (isset($_SESSION["fName"])){
                        $fName = $_SESSION["fName"];
                    }
                    if (isset($_SESSION["fErrors"])){
                        $fErrors = $_SESSION["fErrors"];
                    }
                    if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST)) {              
                        if (isset($_POST["email"]) && $_POST["email"] != NULL) {
                            $fEmail = filter_var($_POST["email"], FILTER_SANITIZE_EMAIL);
                            if (!filter_var($fEmail, FILTER_VALIDATE_EMAIL)) {
                                $fErrors["email"] = "Your email is not valid";
                            }
                        } else {
                            $fErrors["email"] = "Enter an email";
                        }
                        if (isset($_POST["profile_name"]) && $_POST["profile_name"] != NULL) {
                            $fName = filter_var($_POST["profile_name"], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
                            $fName = trim($fName);
                            if (!preg_match("/^[a-zA-Z]{0,50}$/", $fName)) {
                                $fErrors["profile_name"] = "Errors!!! Your profile name can only contain letters)";
                            }
                        } else {
                            $fErrors["profile_name"] = "Enter a profile name";
                        }
                        if (isset($_POST["password"]) && $_POST["password"] != NULL) {
                            $fPassword = filter_var($_POST["password"], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
                            $fPassword = trim($fPassword);
                            if (!preg_match("/^[a-zA-Z\d]{0,20}$/", $fPassword)) {
                                $fErrors["password"] = "Errors!!! Your password can only contain alphanumeric charaters)";
                            }
                        } else {
                            $fErrors["password"] = "Enter a password";
                        }
                        if (isset($_POST["confirm_password"]) && $_POST["confirm_password"] != NULL) {
                            $fCfPassword = filter_var($_POST["confirm_password"], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
                            if ($fPassword != $fCfPassword) {
                                $fErrors["confirm_password"] = "Errors!!! Passwords do not match";
                            }
                        } else {
                            $fErrors["confirm_password"] = "Try enter password again";
                        }
                        if(empty($fErrors)) {
                            if($auth->checkEmail($fEmail)) {
                                $isRegisteredSuccess = $auth->accountRegister($fEmail, $fName, $fPassword);
                                if ($isRegisteredSuccess) {
                                    $auth->accountLogin($fEmail, $fPassword);
                                    if ($auth->checkAuthentication()) {
                                        echo "<h1>Your account has been registered!</h1>";
                                        echo "<p>You will be  redirected.</p>";
                                        echo "</div>";
                                        header("Refresh: 2; URL=friendadd.php");
                                    }
                                } else {
                                    $processErrors["Registration error"] = "Failed!!! Cannot register (SQL error)";
                                }
                            } else {
                                $processErrors["Registration error"] = "Email already existed!";
                            }
                        }
                        $_SESSION["fEmail"] = $fEmail;
                        $_SESSION["fName"] = $fName;
                        $_SESSION["errors"]["fErrors"] = $fErrors;
                        $_SESSION["errors"]["processErrors"] = $processErrors;
                    } 
                    unset($_SESSION["fEmail"]);
                    unset($_SESSION["fName"]);
                    unset($_SESSION["errors"]);
                ?>
                <?php 
                    if($processErrors){
                        foreach ($processErrors as $key => $value) {
                            echo "<h1>$key</h1>";
                            echo "<p>$value</p>";
                        }
                        echo "</div>";
                    }
                ?>
                <div class="form-attribute">
                    <label for="email">Email</label>
                    <input id="email"  type="text" name="email" placeholder="Enter your email" required="required" value="<?php echo $fEmail; ?>" />
                    <?php if(array_key_exists("email", $fErrors)) echo "<div class=\"form-error-feedback\">" . $fErrors["email"] . "</div>";?>
                </div>
                <div class="form-attribute">
                    <label for="profile_name">Profile Name</label>
                    <input id="profile_name"  type="text" name="profile_name" placeholder="Enter your profile name" required="required"  value="<?php echo $fName; ?>"  />
                    <?php if(array_key_exists("profile_name", $fErrors)) echo "<div class=\"form-error-feedback\">" . $fErrors["profile_name"] . "</div>";?>
                </div>
                <div class="form-attribute">
                    <label for="password">Password</label>
                    <input id="password"  type="password" name="password" placeholder="Enter your password" required="required" />
                    <?php if(array_key_exists("password", $fErrors)) echo "<div class=\"form-error-feedback\">" . $fErrors["password"] . "</div>";?>
                </div>
                <div class="form-attribute">
                    <label for="confirm_password">Confirm Password</label>
                    <input id="confirm_password"  type="password" name="confirm_password" placeholder="Confirm your password" required="required" />
                    <?php if(array_key_exists("confirm_password", $fErrors)) echo "<div class=\"form-error-feedback\">" . $fErrors["confirm_password"] . "</div>";?>
                </div>
                <button type="clear" class="outline">Clear</button>
                <button type="submit" class="outline">Register</button>
            </form>
        </div>
    </div>
</body>

</html>